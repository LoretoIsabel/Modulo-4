import java.util.Scanner;

public class For {

	public static void main(String[] args) {
		int cont;
		int res;
		int num;	
		Scanner leer = new Scanner(System.in);
	
		System.out.println("Suma de 100 n�meros desde n�mero elegido");
		System.out.println();
		System.out.println("Ingrese n�mero de inicio: ");
		num = leer.nextInt();
		
		res=num;
				
		for(cont =0; cont<=100+num; cont++) {
			res = res + cont; }	
				System.out.println("La suma es: " + res);
				}
	}


