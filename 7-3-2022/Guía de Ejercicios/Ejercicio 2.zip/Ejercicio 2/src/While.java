import java.util.Scanner;

public class While {

	public static void main(String[] args) {
		int cont;
		cont=0;
		int acum;
		int num;	
		Scanner leer = new Scanner(System.in);

		System.out.println("Suma de 100 n�meros desde n�mero elegido");
		System.out.println();
		System.out.println("Ingrese n�mero de inicio: ");
		num = leer.nextInt();
		acum=num;
		
		 while(cont<100+num) {
			 cont++;
			 acum = acum+(num+cont);
		 }
			System.out.println("La suma es: " + acum);
		}
		}


