import java.util.Scanner;

public class While {

	public static void main(String[] args) {
			int cont;
			int acum;
			int num1;
			int num2;
			Scanner leer = new Scanner(System.in);

		System.out.println("Suma de n�meros entre dos n�meros elegidos");
		System.out.println();
		System.out.println("Ingrese n�mero de inicio: ");
		num1 = leer.nextInt();
		System.out.println("Ingrese n�mero de cierre: ");
		num2 = leer.nextInt();
		acum = num1;
		cont=num1;
		
	
		while (cont < num2){ cont++;
		acum = acum+cont;
		}
		System.out.println("La suma es: " + acum);
		}
	}