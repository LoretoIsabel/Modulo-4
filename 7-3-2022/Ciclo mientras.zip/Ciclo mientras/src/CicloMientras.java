
public class CicloMientras {

	public static void main(String[] args) {
		int cont;
		cont = 0;
		
		do {
			cont = cont + 1;
			System.out.println(cont);
		}
		while(cont < 10);

	}

}
