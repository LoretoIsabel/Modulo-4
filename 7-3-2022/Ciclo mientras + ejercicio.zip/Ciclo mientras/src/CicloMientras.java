
public class CicloMientras {

	public static void main(String[] args) {
		int cont;
		cont = 0;
	
		while(cont <= 10){
			System.out.println(cont);
			cont = cont +1;	
		}
	}
}
