import java.util.Scanner;

public class TablaMultiplicar {
	
	public static void main(String[] args) {
		int cont, num, mult;
		mult=1;
		Scanner leer = new Scanner(System.in);
		System.out.println("Tabla de multiplicar de su n�mero");

		System.out.println("Ingrese un n�mero:  ");
		num = leer.nextInt();
		cont = 0;
		
		while(cont <= 10){
			cont = cont +1;	
			mult=cont*num;
			System.out.println(num,"x", cont, "=", mult);
		}
	}
}
