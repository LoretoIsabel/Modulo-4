import java.util.Scanner;

public class Ejercicio1DoWhile {


	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		float sb,sl,sumaSB, sumaSL,promedioSL;
		float arraysueldos[] = new float[3];
		int cont, cont2;
		cont = 0;
		sumaSB = 0;
		sumaSL = 0;
		promedioSL = 0;
		sl=0;
		
		do {
			System.out.println("Ingrese su sueldo base: " + (cont+1));
			sb = leer.nextFloat();
			sumaSB = sumaSB + sb;
			sl = sb *0.8f;
			arraysueldos[cont] =sl;
			sumaSL = sumaSL + arraysueldos[cont];
			cont++;
		}
		while  (cont<arraysueldos.length); {
			promedioSL = sumaSL / arraysueldos.length;
			cont++;
		}
		System.out.println("Suma sueldos base: " + sumaSB);
		System.out.println("Promedio sueldos l�quidos es: " + promedioSL);
			
		
		}
	}


