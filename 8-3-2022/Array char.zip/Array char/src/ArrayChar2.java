import java.util.Scanner;

public class ArrayChar2 {

	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		char letra;
		char arr[] = new char[4];// juan - Luis - Anto
		
		for(int i=0; i<arr.length; i++) {
			System.out.println("Ingrese letra: "+(i+1));
			letra=leer.next().charAt(0);
			arr[i] = letra;
	}
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i]);
		}
		System.out.println();

		for(int i=arr.length-1; i>=0; i--){
			System.out.print(arr[i]);
		}
	}}
