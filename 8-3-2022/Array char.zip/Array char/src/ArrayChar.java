
public class ArrayChar {

	public static void main(String[] args) {
		char arr[] = new char[4]; //juan
		arr[0] = 'J';
		arr[1] = 'u';
		arr[2] = 'a';
		arr[3] = 'n';
		
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i]);
		}
		
		
	}

}
