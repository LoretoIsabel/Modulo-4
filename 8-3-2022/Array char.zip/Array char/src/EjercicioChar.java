import java.util.Scanner;

public class EjercicioChar {

	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		char letra;
		int cant;
		
		System.out.println("Ingrese cantidad de letras de su palabra: ");
		cant = leer.nextInt();
		char arr[] = new char [cant];
		
		for(int i=0; i<arr.length; i++) {
			System.out.println("Ingrese letra: "+(i+1));
			letra=leer.next().charAt(0);
			arr[i] = letra;
	}
		for(int i=0; i<arr.length; i++) {
			System.out.print(arr[i]);
		}
		System.out.println();

		for(int i=arr.length-1; i>=0; i--){
			System.out.print(arr[i]);
		}
	}}
