package matrices;

import java.util.Scanner;

public class matrizIngresoSolucion {

	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		int ma[][] = new int[3][3];
		
		for(int fila=0; fila<3;fila++) {
			for(int columna=0; columna<3; columna++) {
				ma[fila][columna] = 1;
			}
		}
		for(int fila=0; fila<3; fila++) {
			for(int columna=0; columna<3; columna++) {
				System.out.print(ma[fila][columna]);
				if(columna==2) {
				System.out.println();

			}
		}
	} 		
}
}
