package matrices;

public class matrices2 {

	public static void main(String[] args) {
		int ma[][]= {{0,0,1}, {0,1,0}, {1,0,0}};
		
		System.out.print(ma[2][2]);

	}

}
