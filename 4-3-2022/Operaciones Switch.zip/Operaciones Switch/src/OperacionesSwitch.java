import java.util.Scanner;

public class OperacionesSwitch {

	public static void main(String[] args) {
		Scanner leer = new Scanner(System.in);
		int a;
		int b;
		int opcion;
		int operacion;
		System.out.println("Ingrese primer n�mero");
		a = leer.nextInt();
		
		System.out.println("Ingrese segundo n�mero");
		b = leer.nextInt();
		
		System.out.println("Elija una opci�n para operar\n1 los n�meros se suman\n2 los n�meros se restan\n3 los n�meros se dividen\n4 los n�meros se multiplican");
		opcion = leer.nextInt();
		
		switch(opcion) {
			case 1:
				operacion = a + b;
				System.out.println("La suma es " + operacion);
			break;
			
			case 2:
				operacion = a - b;
				System.out.println("La resta es " + operacion);
			break;
				
			case 3 :
				if(b != 0) {
					operacion = a/b;
					System.out.println("La divisi�n es " + operacion);
				}
				else {
					System.out.println("No puedes dividir por 0");
				}								
			break;
				
			case 4: 
				operacion = a*b;
				System.out.println("La multiplicaci�n es " + operacion);
			break;
				
		}
		

	}

}